#!/usr/bin/env python
# DispersionFree
execution_mode = 'serial'

lattice_file = """

"D1": DRIF,l=1
"D2": DRIF,l=0.5
"D3": DRIF,l=1
"Q1": QUAD,l=0.5
"Q2": QUAD,l=0.5
"Q3": QUAD,l=0.5
"R1": RBEN,angle="18 pi * 180 /",l=0.5
"DBA": LINE=("D3","Q2","D2","Q3","D2","R1","D2","D1","Q1","D1","D2","R1","D2","Q3","D2","Q2","D3")

"""

elegant_file = """

&global_settings
  mpi_io_write_buffer_size = 1048576,
&end

&divide_elements
  maximum_length = 0.1,
  name = "*",
&end

&run_setup
  semaphore_file = run_setup.semaphore,
  centroid = "run_setup.centroid.sdds",
  lattice = "elegant.lte",
  output = "run_setup.output.sdds",
  p_central_mev = 1000,
  parameters = "run_setup.parameters.sdds",
  print_statistics = 1,
  sigma = "run_setup.sigma.sdds",
  use_beamline = "DBA",
&end

&run_control
&end

&twiss_output
  beta_x = 20,
  beta_y = 20,
  filename = "twiss_output.filename.sdds",
  matched = 0,
&end

&bunched_beam
  beta_x = 20,
  beta_y = 20,
  bunch = "bunched_beam.bunch.sdds",
  distribution_cutoff[0] = 3, 3, 3,
  emit_x = 6e-06,
  emit_y = 6e-06,
  enforce_rms_values[0] = 1, 1, 1,
  limit_in_4d = 1,
  n_particles_per_bunch = 20000,
  one_random_bunch = 0,
  sigma_s = 0.00065,
  symmetrize = 1,
  use_twiss_command_values = 1,
&end

&track
&end

"""

with open('elegant.lte', 'w') as f:
    f.write(lattice_file)

with open('elegant.ele', 'w') as f:
    f.write(elegant_file)

import os
os.system('elegant elegant.ele')
