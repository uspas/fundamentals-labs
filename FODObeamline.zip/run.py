"""
Simulation notes:
    For USPAS Jan2019 Fundamentals

"""
# FODObeamline
execution_mode = 'serial'

lattice_file = """

"DIPO": CSBEND,angle="20 pi * 180 /",l=0.5
"D1": DRIF,l=1
"D2": DRIF,l=2
"D3": DRIF,l=0.75
"QD": QUAD,k1=-0.2,l=0.5
"QF": QUAD,k1=0.2,l=0.5
"FODOCELL": LINE=(D1,QF,D2,QD,D1)
"FODOBEAMLINE": LINE=(FODOCELL,FODOCELL,FODOCELL,FODOCELL,FODOCELL,FODOCELL,FODOCELL,FODOCELL,FODOCELL,FODOCELL,FODOCELL,FODOCELL,FODOCELL,FODOCELL,FODOCELL,FODOCELL,FODOCELL,FODOCELL,FODOCELL,FODOCELL)

"""

elegant_file = """

&global_settings
  mpi_io_write_buffer_size = 1048576,
&end

&divide_elements
  maximum_length = 0.1,
  name = "*",
&end

&run_setup
  semaphore_file = run_setup.semaphore,
  centroid = "run_setup.centroid.sdds",
  final = "run_setup.final.sdds",
  lattice = "elegant.lte",
  output = "run_setup.output.sdds",
  p_central_mev = 1000,
  print_statistics = 1,
  sigma = "run_setup.sigma.sdds",
  use_beamline = "FODOcell",
&end

&run_control
&end

&twiss_output
  alpha_x = 0,
  alpha_y = 0,
  beta_x = 4,
  beta_y = 4,
  filename = "twiss_output.filename.sdds",
  matched = 0,
&end

&bunched_beam
  Po = 0,
  alpha_x = 0,
  alpha_y = 0,
  alpha_z = 0,
  beta_x = 4,
  beta_y = 4,
  beta_z = 0,
  bunch = "bunched_beam.bunch.sdds",
  distribution_cutoff[0] = 4, 4, 2,
  emit_x = 6e-06,
  emit_y = 6e-06,
  emit_z = 0,
  enforce_rms_values[0] = 1, 1, 0,
  n_particles_per_bunch = 5000,
  sigma_dp = 0,
  sigma_s = 0.5,
  use_twiss_command_values = 1,
&end

&track
&end

"""

with open('elegant.lte', 'w') as f:
    f.write(lattice_file)

with open('elegant.ele', 'w') as f:
    f.write(elegant_file)

import os
os.system('elegant elegant.ele')
